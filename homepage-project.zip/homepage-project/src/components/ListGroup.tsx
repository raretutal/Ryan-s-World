import { useState } from "react";
//ignore this, this is practice

function ListGroup() {
  let items = ["ASAS", "Yantoks", "Yantoy", "Farlot"];

  const [selectedIndex, setSelectedIndex] = useState(-1);

  return (
    <>
      <h1>LISTS</h1>
      {items.length === 0 ? <p>NOTHIGN</p> : null}
      <ul className="list-group">
        {items.map((item, index) => (
          <li
            className={
              selectedIndex === index
                ? "list-group-item active"
                : "list-group-item"
            }
            key={item}
            onMouseEnter={() => {
              setSelectedIndex(index);
            }}
          >
            {item}
          </li>
        ))}
      </ul>
    </>
  );
}
export default ListGroup;
