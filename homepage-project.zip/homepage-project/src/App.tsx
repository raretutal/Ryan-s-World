import PageBase from "./PageBase";

function App() {
  return (
    <>
      <PageBase />
    </>
  );
}

export default App;
