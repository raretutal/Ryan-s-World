function PageBase() {
  //barebones html
  return (
    <>
      <div className="outside">
        <h1>Welcome to CertifBAI</h1>
        <h5>Your AI-powered career development assistant</h5>
      </div>
      <div className="fourbox">
        <div className="card" id="card1">
          <div className="card-body">
            <h5 className="card-title">Resume Reader</h5>
            <p className="card-text">
              Upload your resume and get professional feedback on its format and
              content
            </p>
            <a href="#" className="btn btn-primary">
              Analyze Resume
            </a>
          </div>
        </div>
        <div className="card" id="card2">
          <div className="card-body">
            <h5 className="card-title">Skill Gap Analyzer</h5>
            <p className="card-text">
              Compare your skills against job requirements and identify areas
              for improvement
            </p>
            <a href="#" className="btn btn-primary">
              Analyze Skills
            </a>
          </div>
        </div>
        <div className="card" id="card3">
          <div className="card-body">
            <h5 className="card-title">Certification Finder</h5>
            <p className="card-text">
              Discover free certifications to enhance your qualifications
            </p>
            <a href="#" className="btn btn-primary">
              Find Certifications
            </a>
          </div>
        </div>
        <div className="card" id="card4">
          <div className="card-body">
            <h5 className="card-title">Job Finder</h5>
            <p className="card-text">
              Find relevant jobs and internships matching your profile
            </p>
            <a href="#" className="btn btn-primary">
              Search Jobs
            </a>
          </div>
        </div>
      </div>
    </>
  );
}

export default PageBase;
